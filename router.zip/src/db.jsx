

export const DOGS = [
    {
        id: 1,
        name: "puli",
        image: "http://placehold.it/600x600"
    },
    {
        id: 2,
        name: 'labrador',
        image: "http://placehold.it/600x600"
    },
    {
        id: 3,
        name: 'Dobberman',
        image: "http://placehold.it/600x600"
    }
]
